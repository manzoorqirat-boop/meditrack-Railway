# MediTrack — Hospital Management System

A full-featured hospital management PWA built with vanilla JS + Firebase.

## Deploy to Railway

1. Push this repo to GitHub
2. Connect repo to Railway
3. Railway auto-detects Node.js and runs `npm start`

## Local Development

```bash
npm install
npm start
```

Open http://localhost:3000
